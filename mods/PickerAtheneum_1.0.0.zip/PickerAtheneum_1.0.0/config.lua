-------------------------------------------------------------------------------
--[MOD CONFIG]--
-------------------------------------------------------------------------------
local PICKER = {}

--Create the Debug option and default to true if this is not a build release
PICKER.DEBUG = false

return PICKER
