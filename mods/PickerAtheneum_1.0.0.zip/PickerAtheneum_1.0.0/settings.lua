data:extend {
    {
        type = 'bool-setting',
        name = 'picker-tool-admin-only',
        setting_type = 'runtime-global',
        default_value = true,
        order = 'picker[admin]'
    }
}