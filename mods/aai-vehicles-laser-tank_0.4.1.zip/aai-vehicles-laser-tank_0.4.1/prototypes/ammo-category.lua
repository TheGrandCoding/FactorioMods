data:extend({
  {
  	type = "ammo-category",
  	name = "laser-cannon",
    bonus_gui_order = "k-b",
  },
})
data.raw["utility-constants"].default.bonus_gui_ordering["laser-cannon"] = "k-b"
