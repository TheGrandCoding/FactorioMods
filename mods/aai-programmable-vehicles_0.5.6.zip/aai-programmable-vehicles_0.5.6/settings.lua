data:extend{
    {
        type = "bool-setting",
        name = "start-with-unit-remote-control",
        setting_type = "startup",
        default_value = true,
    },
    {
        type = "bool-setting",
        name = "start-with-random-color",
        setting_type = "startup",
        default_value = true,
    },
    {
        type = "bool-setting",
        name = "path-visualisation",
        setting_type = "runtime-global",
        default_value = true,
    },
    {
        type = "string-setting",
        name = "hand-deploy-vehicle-ai-default",
        setting_type = "runtime-per-user",
        default_value = 'Auto',
        allowed_values = {'Auto', 'On', 'Off'}
    },
    {
        type = "string-setting",
        name = "exclude-vehicles",
        setting_type = "startup",
        default_value = "",
        allow_blank = true,
    }
}
