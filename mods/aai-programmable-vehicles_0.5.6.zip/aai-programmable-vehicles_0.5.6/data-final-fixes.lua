require("prototypes/item-projectiles")


--log( serpent.block( data.raw["projectile"], {comment = false, numformat = '%1.8g' } ) )
--log( serpent.block( data.raw["utility-sprites"], {comment = false, numformat = '%1.8g' } ) )
