local Data = require('__stdlib__/stdlib/data/data')
Data.Util.disable_control('ReverseEntireBelt')