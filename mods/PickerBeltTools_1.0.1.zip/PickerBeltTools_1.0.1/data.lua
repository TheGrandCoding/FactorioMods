data:extend {
    {
        type = 'custom-input',
        name = 'picker-beltbrush-corners',
        key_sequence = 'CONTROL + SHIFT + R'
    },
    {
        type = 'custom-input',
        name = 'picker-beltbrush-balancers',
        key_sequence = 'CONTROL + SHIFT + B'
    },
    {
        type = 'custom-input',
        name = 'picker-reverse-belts',
        key_sequence = 'ALT + R'
    },

}
