if not angelsmods then angelsmods = {} end
if not angelsmods.addons then angelsmods.addons = {} end
if not angelsmods.addons.petrotrain then angelsmods.addons.petrotrain = {} end

require("prototypes.petro-category")

require("prototypes.entities.petro-train")

require("prototypes.recipes.petro-recipe")

require("prototypes.technology.petro-technology")

