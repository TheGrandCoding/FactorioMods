data:extend(
{
  {
    type = "recipe",
    name = "angels-cab-energy-interface-vequip",
    energy_required = 10,
    enabled = "false",
    ingredients ={
      {"medium-electric-pole", 1},
      {"red-wire", 10},
      {"green-wire", 10},
      {"electronic-circuit", 20},
    },
    result = "angels-cab-energy-interface-vequip",
  },
}
)
