if angelsmods.refining then
	require("prototypes.recipe-builder-fallbacks")
	require("prototypes.refining-override")
	require("prototypes.refining-generate")
	require("prototypes.generation.angels-override")
end

-- EXECUTE OVERRIDES
angelsmods.functions.OV.execute()

angelsmods.functions.update_resource()

angelsmods.functions.index_check()