data:extend({{
	type = "item-with-entity-data",
	name = "vehicle-hauler",
	icon = "__aai-vehicles-hauler__/graphics/icons/hauler.png",
	icon_size = 32,
	subgroup="transport",
    order = "ab[industrial]-b[hauler]",
    stack_size = 1,
	place_result = "vehicle-hauler",
}})
