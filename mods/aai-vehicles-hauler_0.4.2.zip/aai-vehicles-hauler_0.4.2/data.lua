require("prototypes/entity")
require("prototypes/item")
require("prototypes/recipe")
require("prototypes/technology")
