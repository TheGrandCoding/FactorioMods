require("framework"){

	scripts = { -- custom scripts

		"metatables",
		"util",
		"helpers",		
		"setup",
		"drag",
		"cleanup",

	},

	inputs = {  -- custom inputs

		"inventory-cleanup", -- SHIFT + C

	}
	
}