require("prototypes/entity/entity")

require("prototypes/item/item")

require("prototypes/recipe/recipe")

require("prototypes/technology/technology")

require("prototypes/styles")
