-- Used for local testing
local STDLIB = {
    control = false,
}
return STDLIB
