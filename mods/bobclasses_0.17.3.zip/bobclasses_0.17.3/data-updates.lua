local multiplier = data.raw.player.player.inventory_size / 60
if settings.startup["bobmods-plates-inventorysize"] then
  multiplier = settings.startup["bobmods-plates-inventorysize"].value / 60
end

for index, player in pairs(bobmods.classes.players) do
  data.raw.player[player.name].inventory_size = math.floor(data.raw.player[player.name].inventory_size * multiplier)
end


require("bodies-updates")


if data.raw["item-group"]["bob-intermediate-products"] then
  data.raw["item-subgroup"]["body-parts"].group = "bob-intermediate-products"
end