require('prototypes/picker')
require('prototypes/renamer')
require('prototypes/zapper')

require('prototypes/tools')
