local Data = require('__stdlib__/stdlib/data/data')
Data.Util.disable_control('rename')
Data.Util.disable_control('item-grouping-toggle-groups')
Data.Util.disable_control('item-grouping-toggle-subgroups')
