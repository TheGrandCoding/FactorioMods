require("prototypes.entity")
require("prototypes.item")
require("prototypes.recipe")
require("prototypes.technology")

--data_raw_require("resource", "*", {"normal", "infinite_depletion_amount", "minable"})
