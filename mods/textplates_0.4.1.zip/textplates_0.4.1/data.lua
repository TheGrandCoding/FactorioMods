-- not local for this phase
textplates = require("plate-types")
textplates_legacy = true

require("prototype.styles")
require("prototype.item-groups")

require("prototype.entity.entity")
require("prototype.recipe.recipe")
require("prototype.item.item")
